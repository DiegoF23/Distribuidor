import Footer from "../layouts/Footer"
import Analisis1 from "../components/Analisis/Analisis1"

const Analisis = () => {
  return (
    <div>
        <Analisis1 />
        <Footer />
    </div>
  )
}

export default Analisis