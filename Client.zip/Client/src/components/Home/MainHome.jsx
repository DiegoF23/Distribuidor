import React from 'react'

const MainHome = () => {
  return (
    <div>MainHome</div>
  )
}

export default MainHome