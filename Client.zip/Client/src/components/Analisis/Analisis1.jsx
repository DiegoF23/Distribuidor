import React, { useState, useEffect } from "react";
import { Pie, Bar } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from "chart.js";
import axios from "axios";


ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

const Analisis1 = () => {
  const [lote, setLote] = useState({
    producto: "Pepsi 2L",
    pallets: 0,
    basesPorPallet: 0,
    fardosPorBase: 0,
    botellasPorFardo: 0,
  });

  const [stock, setStock] = useState([]);
  const [error, setError] = useState("");

  
  useEffect(() => {
    const fetchStock = async () => {
      try {
        const response = await axios.get("https://jsonplaceholder.typicode.com/users");
        const datosSimulados = [
          { producto: "Pepsi 2L", cantidad: 100 },
          { producto: "Coca-Cola 2L", cantidad: 150 },
          { producto: "Sprite 2L", cantidad: 75 },
        ];
        setStock(datosSimulados);
      } catch (err) {
        setError("Error al cargar los datos del stock.");
      }
    };
    fetchStock();
  }, []);

  // total de botellas en un lote
  const calcularBotellas = () => {
    const { pallets, basesPorPallet, fardosPorBase, botellasPorFardo } = lote;
    return pallets * basesPorPallet * fardosPorBase * botellasPorFardo;
  };

  // lote stock
  const agregarLote = () => {
    const botellas = calcularBotellas();
    if (botellas <= 0) {
      setError("El lote no puede tener 0 botellas.");
      return;
    }

    const nuevoStock = stock.map((item) =>
      item.producto === lote.producto ? { ...item, cantidad: item.cantidad + botellas } : item
    );
    setStock(nuevoStock);
    setError("");
  };

  // gráfico circular
  const dataPie = {
    labels: stock.map((item) => item.producto),
    datasets: [
      {
        label: "Stock",
        data: stock.map((item) => item.cantidad),
        backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0", "#9966FF"],
      },
    ],
  };

  // gráfico de barras
  const dataBar = {
    labels: stock.map((item) => item.producto),
    datasets: [
      {
        label: "Cantidad en stock",
        data: stock.map((item) => item.cantidad),
        backgroundColor: "#36A2EB",
      },
    ],
  };

  return (
    <div>
      <h1>Análisis de Datos</h1>

      {/*lotes */}
      <div>
        <h2>Ingresar Lote</h2>
        {error && <p style={{ color: "red" }}>{error}</p>}
        <div>
          <label>
            Producto:
            <select
              value={lote.producto}
              onChange={(e) => setLote({ ...lote, producto: e.target.value })}
            >
              {stock.map((item) => (
                <option key={item.producto} value={item.producto}>
                  {item.producto}
                </option>
              ))}
            </select>
          </label>
          <label>
            Pallets:
            <input
              type="number"
              value={lote.pallets}
              onChange={(e) => setLote({ ...lote, pallets: parseInt(e.target.value) || 0 })}
            />
          </label>
          <label>
            Bases por pallet:
            <input
              type="number"
              value={lote.basesPorPallet}
              onChange={(e) => setLote({ ...lote, basesPorPallet: parseInt(e.target.value) || 0 })}
            />
          </label>
          <label>
            Fardos por base:
            <input
              type="number"
              value={lote.fardosPorBase}
              onChange={(e) => setLote({ ...lote, fardosPorBase: parseInt(e.target.value) || 0 })}
            />
          </label>
          <label>
            Botellas por fardo:
            <input
              type="number"
              value={lote.botellasPorFardo}
              onChange={(e) => setLote({ ...lote, botellasPorFardo: parseInt(e.target.value) || 0 })}
            />
          </label>
        </div>
        <button onClick={agregarLote}>Agregar Lote</button>
      </div>

      {/* Gráficos */}
      <div>
        <div>
          <h2>Porcentaje de Stock por Producto</h2>
          <Pie data={dataPie} />
        </div>
        <div>
          <h2>Comparación de Stock</h2>
          <Bar data={dataBar} />
        </div>
      </div>
    </div>
  );
};

export default Analisis1;