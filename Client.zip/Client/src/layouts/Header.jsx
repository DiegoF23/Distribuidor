import React from 'react'

const Header = () => {
  return (
    <div>Header a editar</div>
  )
}

export default Header